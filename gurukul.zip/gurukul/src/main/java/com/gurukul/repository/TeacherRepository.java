package com.gurukul.repository;

import com.gurukul.model.Teacher;
import com.gurukul.model.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Long> {

	Teacher findByUser(User user);

}