package com.gurukul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GurukulApplication {

	public static void main(String[] args) {
		SpringApplication.run(GurukulApplication.class, args);
		
		System.err.println("GURUKUL APPLICATION STARTED..");
	}

}
